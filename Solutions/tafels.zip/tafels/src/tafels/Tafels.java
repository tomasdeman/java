package tafels;

import java.util.Arrays;

/**
 * Created by tomasdeman on 20/03/2017.
 */
public class Tafels {
    public static void main(String[] args) {
        int max = 10;
        System.out.println("De tafels van " + max);
        for (int t = 1; t <= max; t++) {
            System.out.println(t + " * " + max + " = " + t * max);
        }

    }
}
