package dobbelen;

/**
 * Created by tomasdeman on 19/03/2017.
 */
public class Main {
    public static void main(String[] args) {

        int aantalStenen = 6;
        int aantalGooien = 1000;

        Dobbelsimulator simul = new Dobbelsimulator();

        simul.drukSimulOpTerminalAf(simul.simul(aantalStenen, aantalGooien), aantalStenen, aantalGooien);

    }
}