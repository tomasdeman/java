package dobbelen;

import java.util.Random;

/**
 * Created by tomasdeman on 19/03/2017.
 */
public class Dobbelsimulator {

    public int gooiDobbelsteen(int aantalZijden) {
        Random r = new Random();
        return r.nextInt(aantalZijden)+1;
    }

    public int somXDobbelstenen(int aantalDobbelstenen) {
        int som = 0;
        for (int i = 0; i < aantalDobbelstenen; i++) {
            som += gooiDobbelsteen(6);
        }
        return som;
    }

    public int[] simul(int aantalDobbelstenen, int aantalGooien) {

        //maak array aan met minimumindex 0 en maximumindex (aantalDobbelstenen * 6)
        int[] ogen = new int[aantalDobbelstenen * 6 + 1];

        //initialiseer alle elementen op 0
        for (int t = 0; t < ogen.length; t++) {
            ogen[t] = 0;
        }

        //simuleer nu de dobbelgooien en tel deze bij het juiste element van de array op
        for (int t = 0; t < aantalGooien; t++) {
            ogen[somXDobbelstenen(aantalDobbelstenen)]++;
        }

        //geef de array met de simulatiewaardes terug
        return ogen;
    }

    public void drukSimulOpTerminalAf(int[] ogen, int aantalDobbelstenen, int aantalGooien) {

        int min = aantalDobbelstenen * 1;
        int max = aantalDobbelstenen * 6;

        System.out.println("Simulatie: " + aantalGooien + "  keer gooien met " + aantalDobbelstenen + " dobbelstenen leverde volgende sommen op");

        for (int i = min; i <= max; i++) {
            System.out.println(i + " : " + ogen[i] + " keer gegooid.");
        }
    }



}
