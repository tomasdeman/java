package mediaan;

import java.util.Random;

/**
 * Created by tomasdeman on 22/03/2017.
 */
public class Main {
    public static void main(String[] args) {

        //Maak een array en een random generator
        double[] array = new double[5];
        Random rg = new Random();

        //Vul de array met random doubles (en druk deze af)
        for (int i = 0; i < array.length; i++) {
            array[i] = rg.nextDouble() * 100;
        }

        //print de mediaan
        System.out.print("Mediaan: " + Mediaan.berekenMediaan(array));

    }
}
