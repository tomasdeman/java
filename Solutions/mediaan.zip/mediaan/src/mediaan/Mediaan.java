package mediaan;

import java.util.Arrays;

/**
 * Created by tomasdeman on 22/03/2017.
 */
public class Mediaan {
    public static double berekenMediaan(double[] getallen) {


        //sorteer de array
        Arrays.sort(getallen);

        for (int i = 0; i < getallen.length; i++) {
            System.out.println(getallen[i] );
        }

        //controleer of de array een even aantal elementen bevat
        if (getallen.length%2 == 0) {
            //neem de twee middenste elementen van de array
            double a, b;
            a = getallen[getallen.length / 2 - 1];
            b = getallen[getallen.length / 2 ];
            //geef het gemiddelde van deze twee getallen terug
            return (a + b) / 2;
        } else {
            //geef het middenste element terug
            return getallen[(getallen.length - 1) / 2];
        }



    }
}
