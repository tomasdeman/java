package game;

/**
 * Created by tomasdeman on 21/04/2017.
 */
public class Main {
    public static void main(String[] args) {
        Game g = new Game();
        g.start();
        //g.printDraken();

    }
}
