package game;

/**
 * Created by tomasdeman on 21/04/2017.
 */
public abstract class Vijand {

    private String naam;
    private String voornaam;

    public Vijand(String naam, String voornaam) {
        this.naam = naam;
        this.voornaam = voornaam;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getVoornaam() {
        return voornaam;
    }

    public void setVoornaam(String voornaam) {
        this.voornaam = voornaam;
    }

    public void print() {
        System.out.println("Ik ben " + voornaam + " " + naam);
    }

    public abstract void valAan();
}
