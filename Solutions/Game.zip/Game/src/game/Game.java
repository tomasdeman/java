package game;

import java.util.ArrayList;

/**
 * Created by tomasdeman on 21/04/2017.
 */
public class Game {

    private ArrayList<Vijand> list;

    public Game() {
        list = new ArrayList<>();
    }

    public void start() {
        list.add(new Trol("De stinkende", "Oluf", 3.2, 10));
        list.add(new Trol("De luizige", "Ballaw", 3.2, 10));
        list.add(new Draak("De Brander", "Erguin", "rood", 10, 5));
        list.add(new Draak("Smeltens", "Alice", "oranje", 12, 15));

        printVijanden();
        valAanVijanden();
    }

    public void printVijanden() {
        System.out.println("Even de vijanden voorstellen:");
        printDraken();
        printTrollen();
    }

    public void printDraken() {
        System.out.println("Dit zijn alle draken");
        for (Vijand v: list) {
            if (v instanceof Draak) {
                v.print();
            }
        }
        System.out.println("");
    }

    public void printTrollen() {
        System.out.println("Dit zijn alle trollen");
        for (Vijand v: list) {
            if (v instanceof Trol) {
                v.print();
            }
        }
        System.out.println("");
    }

    public void valAanVijanden() {
        System.out.println("WAT GEBEURT ER?! IEDEREEN VALT AAN!!!!");
        for (Vijand vijand : list) {
            vijand.valAan();
        }
        System.out.println("");
    }

}
