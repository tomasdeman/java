package game;

/**
 * Created by tomasdeman on 21/04/2017.
 */
public class Trol extends Vijand {

    private double grootte;
    private double snelheid;
    private int knotsgrootte;

    public Trol(String naam, String voornaam, double grootte, double snelheid) {
        super(naam, voornaam);
        this.grootte = grootte;
        this.snelheid = snelheid;
        this.knotsgrootte = 1 + (int) (Math.random() * 4);
    }

    public double getGrootte() {
        return grootte;
    }

    public void setGrootte(double grootte) {
        this.grootte = grootte;
    }

    public double getSnelheid() {
        return snelheid;
    }

    public void setSnelheid(double snelheid) {
        this.snelheid = snelheid;
    }

    public void slaMetKnots(int knotsGrootte) {
        System.out.println(this.getVoornaam() + " " + this.getNaam() + " zegt: BOEM! BAF! Iedereen doodgemept met mijn knots van " + knotsGrootte + "m lang");
    }

    public void print() {
        super.print();
        System.out.println("Deze trol is " + getGrootte() + "m hoog en kan wel aan " + snelheid + "km/u lopen!");
        System.out.println("");
    }

    @Override
    public void valAan() {
        slaMetKnots(knotsgrootte);
        System.out.println("");
    }
}
