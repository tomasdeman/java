package game;

/**
 * Created by tomasdeman on 21/04/2017.
 */
public class Draak extends Vijand {
    private String kleur;
    private double vleugelbreedte;
    private double radius;

    public Draak(String naam, String voornaam, String kleur, double vleugelbreedte, double radius) {
        super(naam, voornaam);
        this.kleur = kleur;
        this.vleugelbreedte = vleugelbreedte;
        this.radius = radius;
    }

    public String getKleur() {
        return kleur;
    }

    public void setKleur(String kleur) {
        this.kleur = kleur;
    }

    public double getVleugelbreedte() {
        return vleugelbreedte;
    }

    public void setVleugelbreedte(double vleugelbreedte) {
        this.vleugelbreedte = vleugelbreedte;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void spuwVuur() {
        System.out.println(this.getVoornaam() + " " + this.getNaam() + "valt aan!");
        System.out.println("Iedereen in een straal van " + radius + "km is geroosterd!!");
        System.out.println("");
    }

    public void print() {
        super.print();
        System.out.println("Ik ben een draak. Mijn schubben zijn " + getKleur() + ". Mijn vleugels zijn wel " + vleugelbreedte + " breed. Vuur spuwen kan ik wel tot " + radius + "m ver!");
        System.out.println("");
    }

    @Override
    public void valAan() {
        spuwVuur();
    }
}
