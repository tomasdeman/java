package eratosthenes;

/**
 * Created by tomasdeman on 19/03/2017.
 */
public class Primes {
    public void printPrimes(int max) {

        boolean isPrime[] = new boolean[max+1];

        for (int i = 0; i < isPrime.length; i++) {
            isPrime[i] = true;
        }

        isPrime[0] = false;
        isPrime[1] = false;

        for (int i = 2; i < isPrime.length; i++) {
            if (isPrime[i]) {
                for (int j = i * 2; j < isPrime.length; j += i) {
                    isPrime[j] = false;
                }
            }
        }

        System.out.println("De priemgetallen met als maximumgrens " + max + " zijn:");

        int teller = 0;
        for (int i = 2; i < isPrime.length; i++) {
            if (isPrime[i]) {
                teller++;
                if (teller < 10) {
                    System.out.print(i + " ");
                }
                else {
                    System.out.println(i + " ");
                    teller = 0;
                }
            }
        }
    }
}