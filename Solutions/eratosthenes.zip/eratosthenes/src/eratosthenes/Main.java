package eratosthenes;

/**
 * Created by tomasdeman on 19/03/2017.
 */
public class Main {
    public static void main(String[] args) {

        Primes e = new Primes();
        e.printPrimes(1000);

    }
}
